/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
*/
package service;

import java.util.List;
import models.Carro;


public interface CarroService {
    public List<Carro> findAllCarro();
    public void  addCarro(Carro carro);
    
}
