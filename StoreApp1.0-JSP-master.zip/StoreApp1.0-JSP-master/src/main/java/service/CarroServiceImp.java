/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
*/
package service;

import data.CarroDAO;
import java.util.List;
import javax.inject.Inject;
import models.Carro;

public class CarroServiceImp implements CarroService{

    @Inject
    private CarroDAO cDAO;
    @Override
    public List<Carro> findAllCarro() {
         return cDAO.findAllCarro();
        }

    @Override
    public void addCarro(Carro carro) {
        cDAO.addCarro(carro);
    }
    
    
}
