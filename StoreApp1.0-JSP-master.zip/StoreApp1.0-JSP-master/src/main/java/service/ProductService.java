/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
*/
package service;

import java.util.List;
import models.Product;

public interface ProductService {
    public List<Product> findAllProducts();
    public Product findAllProductsById(Product product);
    public List<Product> findProductyName(String filter);
    public void deleteProduct(Product p);
    public void addProduct(Product p);
    public void updateProduct(Product p);
}
