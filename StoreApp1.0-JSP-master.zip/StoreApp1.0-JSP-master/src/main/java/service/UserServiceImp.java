/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
 */
package service;

import data.UserDAO;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import models.User;

@Stateless
public class UserServiceImp implements UserService {

    @Inject
    UserDAO userDAO;

    @Override
    public User validateUser(String user, String pwd) {
        return userDAO.validateUser(user, pwd);

    }

    @Override
    public List<User> findAllUser() {
        return userDAO.findAllUser();
    }

    @Override
    public void insertUser(User User) {
        userDAO.insertUser(User);
    }

    @Override
    public void deleteUser(User User) {
        userDAO.deleteUser(User);
    }

    @Override
    public void updateUser(User User) {
        userDAO.updateUser(User);
    }

    @Override
    public User findAllUserByID(User user) {
        return userDAO.findAllUserById(user);
    }

    @Override
    public List<User> findAllUser(String filter) {
        return userDAO.findAllUser(filter);
    }

}
