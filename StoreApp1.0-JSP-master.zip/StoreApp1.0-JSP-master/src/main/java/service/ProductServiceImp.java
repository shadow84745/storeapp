/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
 */
package service;

import data.ProductDAO;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import models.Product;

@Stateless
public class ProductServiceImp implements ProductService {

    @Inject
    private ProductDAO pDAO;

    @Override
    public List<Product> findAllProducts() {
        return pDAO.findAllProducts();
    }

    @Override
    public void deleteProduct(Product p) {
        pDAO.deleteProduct(p);
    }

    @Override
    public void addProduct(Product p) {
        pDAO.addProduct(p);
    }

    @Override
    public Product findAllProductsById(Product product) {
        return pDAO.findProductyId(product);
    }

    @Override
    public void updateProduct(Product p) {
        pDAO.updateProduct(p);
    }

    @Override
    public List<Product> findProductyName(String filter) {
        return pDAO.findProductyName(filter);

    }

}
