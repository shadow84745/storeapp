/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
*/
package service;

import java.util.List;
import javax.ejb.Stateless;
import models.User;

public interface UserService {
    public User validateUser(String user, String pwd);
    public List<User> findAllUser();
    public List<User> findAllUser(String filter);    
    public User findAllUserByID(User user);
    public void insertUser(User User);
    public void deleteUser(User User);
    public void updateUser(User User);
    
    
}
