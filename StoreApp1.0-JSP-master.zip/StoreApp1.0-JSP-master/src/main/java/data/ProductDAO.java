/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
*/
package data;

import java.util.List;
import models.Product;

public interface ProductDAO {
    public List<Product> findAllProducts();
    public Product findProductyId(Product Product);
    public List<Product> findProductyName(String filter);
    public void  addProduct(Product p);
    public void deleteProduct(Product p);
    public void  updateProduct(Product p);
    
}
