/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
*/
package data;

import java.util.List;
import models.Carro;

/**
 *
 * @author USUARIO
 */
public interface CarroDAO {
    
    public List<Carro> findAllCarro();
    
    public void  addCarro(Carro carro);
    
}
