/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
 */
package data;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import models.Product;

@Stateless
public class ProductDAOimp implements ProductDAO {

    @PersistenceContext(unitName = "dbStoreJTAPU") //Para indicat la unidad de persistencia JTA
    EntityManager em;

    @Override
    public List<Product> findAllProducts() {
        //return em.createNamedQuery("Product.findAll").getResultList();
        Query query;
        query = em.createQuery("SELECT p FROM Product p");
        return query.getResultList();
    }

    @Override
    public void addProduct(Product p) {
        try {
            em.persist(p);
        } catch (Exception e) {
            System.out.println("Exception:" + e.getMessage());
        }

    }

    @Override
    public void deleteProduct(Product p) {
        em.remove(em.merge(p));
    }

    @Override
    public Product findProductyId(Product Product) {
        return em.find(Product.class, Product.getProductId());

    }

    @Override
    public void updateProduct(Product p) {
        em.merge(p);
    }

    @Override
    public List<Product> findProductyName(String filter) {
        Query query;
        query = em.createQuery("SELECT p FROM Product p WHERE p.productName LIKE :filter ORDER BY p.productName");
        query.setParameter("filter", "%" + filter + "%");
        return query.getResultList();
    }

}
