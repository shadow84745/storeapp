/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
*/
package data;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import models.User;

@Stateless
public class UserDAOImp implements UserDAO{
    
    @PersistenceContext(unitName = "dbStoreJTAPU") //Para indicat la unidad de persistencia JTA
    EntityManager em;

    
    
    @Override
    public User validateUser(String user, String pwd) {
        Query query;
        query = em.createQuery("SELECT u FROM User u WHERE u.user = :user AND u.pwd = :pwd");
        query.setParameter("user", user);
        query.setParameter("pwd", pwd);
        return (User)query.getSingleResult();
    }

    @Override
    public List<User> findAllUser() {
     return em.createNamedQuery("User.findAll").getResultList();   
    }

    @Override
    public void insertUser(User User) {
       try {
            em.persist(User);
        }
        catch(Exception e){
            System.out.println("Exception:" + e.getMessage());
        }    
    }

    @Override
    public void deleteUser(User User) {
    em.remove(em.merge(User));    
    }

    @Override
    public void updateUser(User User) {
            em.merge(User);
    }

    @Override
    public User findAllUserById(User user) {
         return em.find(User.class, user.getId());
    }

    @Override
    public List<User> findAllUser(String filter) {
     Query query;
        query = em.createQuery("SELECT u FROM User u WHERE u.user LIKE :filter ORDER BY u.user");
        query.setParameter("filter", "%"+filter+"%");
        return query.getResultList();   
    }




   
    
}
