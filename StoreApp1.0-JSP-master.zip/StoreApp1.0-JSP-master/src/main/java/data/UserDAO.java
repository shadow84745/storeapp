/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
*/
package data;

import java.util.List;
import models.User;


public interface UserDAO {
    public User validateUser(String user, String pwd);
    public List<User> findAllUser();
    public List<User> findAllUser(String filter);    
    public User findAllUserById(User user);
    public void insertUser(User User);
    public void deleteUser(User User);
    public void updateUser(User User);
    
    
}
