/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
 */
package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Sales;
import models.User;
import service.UserService;

@WebServlet(name = "UserServlet", urlPatterns = {"/UserServlet"})
public class UserServlet extends HttpServlet {

    @Inject
    private UserService uService;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String action = request.getParameter("action");
            if (action == null) {
                action = request.getServletPath();
            }
            //String filter = request.getParameter("filter");
            //System.out.println("Action CS:" + action);
            switch (action) {
                case "users": {
                    List<User> Lp = uService.findAllUser();
                    request.setAttribute("User", Lp);
                    request.getRequestDispatcher("/users.jsp").forward(request, response);
                }
                ;
                break;
                case "add":
                    addUser(request, response);
                    break;
                case "delete":
                    deleteUser(request, response);
                    break;
                case "update":
                    updateUser(request, response);
                    break;
                case "search":
                    searchBar(request, response);
                    break;
                case "closeSession":
                    closeSession(request, response);
                    break;
            }

            return;
        }

    }

//Buscar desde la barra de navegacion por ID o NAME    
    protected void searchBar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String filter = request.getParameter("filter");
        int typeSearch = Integer.parseInt(request.getParameter("typeSearch"));
        User usuario = new User();
        List<User> listUser = new ArrayList<>();
        if (filter == "") {
            request.setAttribute("message", "<h3 style=`color:red;`>Error empty input can´t be found!</h3>");
            request.setAttribute("User", listUser);
            request.getRequestDispatcher("/users.jsp").forward(request, response);
            return;
        }
        switch (typeSearch) {
            case 1: {
                usuario.setId(Integer.parseInt(filter));
                if (uService.findAllUserByID(usuario) != null) {
                    listUser.add(uService.findAllUserByID(usuario));
                }
                request.setAttribute("message", "sucess!");

            }
            ;
            break;
            case 2: {
                listUser = uService.findAllUser(filter);
                request.setAttribute("message", "sucess " + listUser.size() + " have been found!");
            }
            ;
            break;
            default: {
                request.setAttribute("message", "<h3 style=`color:red;`>Error!</h3>");
            }
            ;
            break;

        }
        request.setAttribute("User", listUser);
        request.getRequestDispatcher("/users.jsp").forward(request, response);
        return;
    }

//Añadir Usuario 
    protected void addUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User U = new User();
        PrintWriter out = response.getWriter();

        U.setId(Integer.parseInt(request.getParameter("ID")));
        U.setUser(request.getParameter("User"));
        U.setPwd(request.getParameter("Password"));

        uService.insertUser(U);
        request.setAttribute("message", "User successfully added!");
        List<User> Lp = uService.findAllUser();
        request.setAttribute("User", Lp);
        request.getRequestDispatcher("/users.jsp").forward(request, response);

    }

//Actualizar Usuario    
    protected void updateUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User U = new User();
        PrintWriter out = response.getWriter();

        U.setId(Integer.parseInt(request.getParameter("ID")));
        U.setUser(request.getParameter("User"));
        U.setPwd(request.getParameter("Password"));
        uService.updateUser(U);
        request.setAttribute("message", "User successfully updated!");
        List<User> Lp = uService.findAllUser();
        request.setAttribute("User", Lp);
        request.getRequestDispatcher("/users.jsp").forward(request, response);

    }

//Sesion de la pagina. 
    protected void closeSession(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.removeAttribute("userO");
        request.getRequestDispatcher("/index.jsp").forward(request, response);
        return;
    }

    protected void deleteUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        User U = new User();
        String userId = request.getParameter("ID");
        PrintWriter out = response.getWriter();

        U.setId(Integer.parseInt(userId));

        U = uService.findAllUserByID(U);

        if (U != null) {
            uService.deleteUser(U);
            request.setAttribute("message", "User successfully deleted!");
        } else {
            request.setAttribute("message", "Error id delete User!");
        }

        List<User> Lp = uService.findAllUser();
        request.setAttribute("User", Lp);
        request.getRequestDispatcher("/users.jsp").forward(request, response);

        return;

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
