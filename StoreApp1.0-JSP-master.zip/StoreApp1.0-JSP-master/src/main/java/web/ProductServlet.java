/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
 */
package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Category;
import models.Product;
import models.User;
import service.ProductService;

@WebServlet(name = "ProductServlet", urlPatterns = {"/ProductServlet"})
public class ProductServlet extends HttpServlet {

    @Inject
    ProductService pService;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        String action = request.getParameter("action");
        if (action == null) {
            action = request.getServletPath();
        }

        PrintWriter out = response.getWriter();
        out.print(action);
        //String filter = request.getParameter("filter");
        //System.out.println("Action CS:" + action);
        switch (action) {
            case "products": {
                List<Product> Lp = pService.findAllProducts();
                request.setAttribute("Products", Lp);
                // out.print(Lp.get(0).getCategoryId());
                request.getRequestDispatcher("/products.jsp").forward(request, response);
            }
            ;
            break;
            case "add":
                addProduct(request, response);
                break;
            case "delete":
                deleteProduct(request, response);
                break;
            case "update":
                updateProduct(request, response);
                break;
            case "search":
                searchBar(request, response);
                break;
        }

        List<Product> Lp = pService.findAllProducts();
        request.setAttribute("Products", Lp);
        // out.print(Lp.get(0).getCategoryId());
        System.out.println(Lp.get(0));
        request.getRequestDispatcher("/products.jsp").forward(request, response);
        return;

    }
//Insertar producto

    protected void addProduct(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Product p = new Product();
        PrintWriter out = response.getWriter();
        String productID = request.getParameter("productoId");
        //out.print(productID);
        p.setProductId(Integer.parseInt(productID));
        p.setProductName(request.getParameter("productName"));
        p.setPrice(request.getParameter("price"));
        Category category = new Category(Integer.parseInt(request.getParameter("categoryID")));
        p.setCategoryId(category);
        pService.addProduct(p);
        request.setAttribute("message", "Product successfully added!");
    }
//Actualizar de la lista un producto

    protected void updateProduct(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Product p = new Product();
        PrintWriter out = response.getWriter();
        String productID = request.getParameter("productoId");

        //out.print(productID);
        p.setProductId(Integer.parseInt(productID));
        p.setProductName(request.getParameter("productName"));
        p.setPrice(request.getParameter("price"));
        Category category = new Category(Integer.parseInt(request.getParameter("categoryID")));
        p.setCategoryId(category);
        pService.updateProduct(p);
        request.setAttribute("message", "Product successfully updated!");
    }
//Buscar desde la barra de navegacion por ID o NAME

    protected void searchBar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String filter = request.getParameter("filter");
        int typeSearch = Integer.parseInt(request.getParameter("typeSearch"));
        Product producto = new Product();
        List<Product> listProduct = new ArrayList<>();
        if (filter == "") {
            request.setAttribute("message", "<h3 style=`color:red;`>Error empty input can´t be found!</h3>");
            request.setAttribute("Products", listProduct);
            request.getRequestDispatcher("/products.jsp").forward(request, response);
            return;
        }
        switch (typeSearch) {
            case 1: {
                producto.setProductId(Integer.parseInt(filter));
                if (pService.findAllProductsById(producto) != null) {
                    listProduct.add(pService.findAllProductsById(producto));
                }
                request.setAttribute("message", "sucess!");

            }
            ;
            break;
            case 2: {
                listProduct = pService.findProductyName(filter);
                request.setAttribute("message", "sucess " + listProduct.size() + " have been found!");
            }
            ;
            break;
            default: {
                request.setAttribute("message", "<h3 style=`color:red;`>Error!</h3>");
            }
            ;
            break;

        }
        request.setAttribute("Products", listProduct);
        request.getRequestDispatcher("/products.jsp").forward(request, response);
        return;

    }

    protected void deleteProduct(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Product p = new Product();
        String productId = request.getParameter("productId");
        PrintWriter out = response.getWriter();

        p.setProductId(1);
        System.out.println("delete.Product: " + productId);
        p = pService.findAllProductsById(p);

        if (p != null) {
            pService.deleteProduct(p);
            request.setAttribute("message", "Product successfully deleted!");
        } else {
            request.setAttribute("message", "Error id delete Product!");
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
