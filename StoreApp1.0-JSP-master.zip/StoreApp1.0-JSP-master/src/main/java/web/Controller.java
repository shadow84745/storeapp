/*PRESENTADO POR:
    MARIA DE LOS ANGELES CUELLAR MURILLO
    MIGUEL ANGEL CUELLAR VELANDIA 
    SERGIO ENRIQUE GUEVARA PUENTES
    EMANUEL RIOS RICARDO
    CRISTIAN CAMILO VALENCIA GARCIA
    
*/
package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Customer;
import models.User;
import service.CustomerService;

public class Controller extends HttpServlet {

    @Inject
    CustomerService cService;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
             

            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Controller</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Controller at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);

        String action = request.getParameter("action");
      PrintWriter out  = response.getWriter();
        System.out.println("Action Get:" + action);
         out.println("<!DOCTYPE html>");
        switch (action) {
            case "main":
                request.getRequestDispatcher("main.jsp").forward(request, response);
                break;
            case "customers":
                request.getRequestDispatcher("CustomerServlet?action=customers").forward(request, response);
                break;
            case "products":
                request.getRequestDispatcher("ProductServlet?action=products").forward(request, response);
                break;
            case "sales":
                request.getRequestDispatcher("SalesServlet?action=sales").forward(request, response);
                break;
            case "users":
                request.getRequestDispatcher("UserServlet?action=users").forward(request, response);
                break;
            case "home":
                request.getRequestDispatcher("PSelectServlet?action=home").forward(request, response);
                break;
        }
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        System.out.println(request.getAttribute("userO")==null);
        if(request.getAttribute("userO")==null){
           request.getRequestDispatcher("index.jsp").forward(request, response);
            return;
        }
        
        
     /*   if (userO != null) {
                request.setAttribute("userO", userO);
                request.getRequestDispatcher("Controller?action=main").forward(request, response);
            } else {
                request.getRequestDispatcher("index.jsp").forward(request, response);

            }*/
        switch (action) {
            case "main":
                request.getRequestDispatcher("main.jsp").forward(request, response);
                break;
            case "customers":
                request.getRequestDispatcher("CustomerServlet?action=customers").forward(request, response);
                break;
            case "products":
                request.getRequestDispatcher("ProductServlet?action=products").forward(request, response);
                break;
            case "sales":
                request.getRequestDispatcher("SalesServlet?action=sales").forward(request, response);
                break;
            case "users":
                request.getRequestDispatcher("UserServlet?action=users").forward(request, response);
                break;
                  case "home":
                request.getRequestDispatcher("PSelectServlet?action=home").forward(request, response);
                break;
        }
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    protected void listCustomers(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String filter = request.getParameter("filter");
        //System.out.println(filter);
        if(filter==null) filter="";
        List<Customer> c= cService.findAllCustomer(filter);
        request.setAttribute("customers", c);
        request.getRequestDispatcher("/customers.jsp").forward(request, response);
    }

}
